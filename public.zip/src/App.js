
import RegistrationForm from "./components/RegistrationForm";
import Listing from "./components/SingleView";


function App() {
  return (
    <>
      <RegistrationForm />
      <Listing />
    </>
  );
}

export default App;
